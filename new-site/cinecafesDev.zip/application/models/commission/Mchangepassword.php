<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mchangepassword extends CI_Model {

    


}