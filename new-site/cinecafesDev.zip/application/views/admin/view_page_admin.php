
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">View Page</h1>
          <div class="form_panel">          		
            <div class="row">
            	<div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>First Name*</label>
                        <p>Pampa</p>
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Last Name*</label>                       
                        <p>Saha</p>
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Email*</label>                        
                        <p>pampasaha@gmail.com</p>
                    </div>
                </div>
                
                 <div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Sex*</label>                       
                        <p>Female</p>
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Phone No*</label>
                        <p>9125365874</p>
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Location*</label>                       
                        <p>Kolkata</p>
                    </div>
                </div>
                
                 <div class="col-md-12 col-sm-12 col-xs-12">
                	<div class="form-group">
                    	<label>Message*</label>
                        <p>This is a test</p>
                    </div>
                </div>
            
            </div>          
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      
